// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  firebaseConfig: {
    apiKey: "AIzaSyAZj_B7-oUplWGLnq9z8ExdSOllfncCTRI",
    authDomain: "turistear-4496b.firebaseapp.com",
    projectId: "turistear-4496b",
    storageBucket: "turistear-4496b.appspot.com",
    messagingSenderId: "662967360042",
    appId: "1:662967360042:web:a2bb80c642721384848153",
    measurementId: "G-7QC4ZP4RMW"
  }
}
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
