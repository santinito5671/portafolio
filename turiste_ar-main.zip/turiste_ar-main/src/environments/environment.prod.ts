export const environment = {
  production: true,

  firebaseConfig: {
    apiKey: "AIzaSyAZj_B7-oUplWGLnq9z8ExdSOllfncCTRI",
    authDomain: "turistear-4496b.firebaseapp.com",
    projectId: "turistear-4496b",
    storageBucket: "turistear-4496b.appspot.com",
    messagingSenderId: "662967360042",
    appId: "1:662967360042:web:a2bb80c642721384848153",
    measurementId: "G-7QC4ZP4RMW"
  }
};
