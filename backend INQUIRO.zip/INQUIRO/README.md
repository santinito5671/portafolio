# -Practica-Proyecto-Node.Js-con-AWS
Se usa DynamoDb como bd NOSQL y un deploy en Elastic Beanstalk
