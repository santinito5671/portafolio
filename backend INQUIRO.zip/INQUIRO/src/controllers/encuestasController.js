import { crearEncuestaService,cambiarEstadoEncuestaService,eliminarEncuestaService, obtenerTodosLosEmailsClienteService,obtenerTodasLasEncuestasService,obtenerEncuestasPorPkService, obtenerEncuestaPorSkService, obtenerEncuestaPorSkGSIService, actualizarEncuestaService } from '../service/encuestasService.js';
import { v4 as uuidv4 } from "uuid"
import generarNuevaEncuesta from "../utils/generarNuevaEncuesta.js"
//Hoy en dia las validaciones no tienen porque ser tan fuertes. Ya que lo manejaremos nosotros a la app.

const crearEncuestaController = async (req, res) => {
 const { email, titulo, descripcion, preguntas } = req.body;
 const idEncuesta = uuidv4();

  if ( !email || !titulo || !descripcion || !Array.isArray(preguntas) || preguntas.length === 0) {
    return res.status(400).json({ message: 'Datos inválidos' });
  }

  const nuevaEncuesta = generarNuevaEncuesta(email, titulo, preguntas,idEncuesta,descripcion);

  try {
    const encuestaCreada = await crearEncuestaService(nuevaEncuesta);
    res.status(201).json(encuestaCreada);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const obtenerTodosLosEmailsClienteController = async (req, res) => {

  try {
    const emails = await obtenerTodosLosEmailsClienteService();
    if (emails.length === 0) {
      return res.status(404).json({ message: 'No se encontraron emails de cliente' });
    }
    res.status(200).json({ emails });  
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const obtenerTodasLasEncuestasController = async (req, res) => {
  try {
    const encuestas = await obtenerTodasLasEncuestasService();
    if (encuestas.length === 0) {
      return res.status(404).json({ message: 'No se encontraron encuestas.' });
    }
    res.status(200).json({ encuestas });  
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const obtenerEncuestasPorPkController = async (req, res) => {
 const { email } = req.params;

  if ( !email ) {
    return res.status(400).json({ message: 'No se ingreso un email valido' });
  }

  try {
    const encuestas = await obtenerEncuestasPorPkService(email);
    if (encuestas.length === 0) {
      return res.status(404).json({ message: 'No se encontraron encuestas para este usuario.' });
    }
    res.status(200).json({ encuestas });  
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const obtenerEncuestaPorSkController = async (req, res) => {
 const { email, sk } = req.params;

  if ( !email || !sk ) {
    return res.status(400).json({ message: 'No se ingreso un id valido' });
  }

  try {
    const encuesta = await obtenerEncuestaPorSkService(email,sk);

    res.status(200).json({ encuesta });  
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const obtenerEncuestaPorSkGSIController = async (req, res) => {
 const { sk } = req.params;

  if ( !sk ) {
    return res.status(400).json({ message: 'No se ingreso un id valido' });
  }

  try {
    const encuesta = await obtenerEncuestaPorSkGSIService(sk);

    res.status(200).json({ encuesta });  
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
const cambiarEstadoEncuestaController = async (req, res) => {
  try {
    const { pk, sk, nuevoEstado } = req.body;

    if (!pk || !sk || !nuevoEstado) {
      return res.status(400).json({
        message: "Faltan datos: pk, sk o nuevoEstado son requeridos.",
      });
    }

    const estadosPermitidos = ["pausada", "cerrada"];
    if (!estadosPermitidos.includes(nuevoEstado)) {
      return res.status(400).json({
        message: "Estado inválido. Solo se permite 'pausada' o 'cerrada'.",
      });
    }

    const encuestaActualizada = await cambiarEstadoEncuestaService(pk, sk, nuevoEstado);

    res.status(200).json({
      message: `Encuesta ${nuevoEstado} correctamente.`,
      data: encuestaActualizada,
    });
  } catch (error) {
    res.status(500).json({
      message: `Error al cambiar el estado de la encuesta: ${error.message}`,
    });
  }
};

const actualizarEncuestaController = async (req, res) => {
  try {
    const { pk, sk } = req.params;
    const { titulo, preguntas } = req.body;

    if (!pk || !sk) {
      return res.status(400).json({ message: 'Faltan parámetros: pk o sk.' });
    }

    if (!titulo && !preguntas) {
      return res.status(400).json({ message: 'Debe proporcionar al menos un campo para actualizar.' });
    }

    const encuestaNueva = await actualizarEncuestaService(pk, sk, titulo, preguntas);

    res.status(200).json({
      message: 'Encuesta actualizada correctamente.',
      encuestaNueva
    });
  } catch (error) {
    res.status(500).json({ message: `Error al actualizar la encuesta: ${error.message}` });
  }
};
const eliminarEncuestaController = async (req, res) => {
  try {
    const { pk, sk } = req.params;

    if (!pk || !sk) {
      return res.status(400).json({ message: 'Faltan parámetros: pk o sk.' });
    }

    await eliminarEncuestaService(pk, sk);

    res.status(200).json({ message: 'Encuesta eliminada correctamente.' });
  } catch (error) {
    console.error('Error al eliminar la encuesta:', error);
    res.status(500).json({
      message: `Error al eliminar la encuesta: ${error.message}`,
    });
  }
};

export { crearEncuestaController, obtenerTodosLosEmailsClienteController, obtenerTodasLasEncuestasController,obtenerEncuestasPorPkController, obtenerEncuestaPorSkController, obtenerEncuestaPorSkGSIController,actualizarEncuestaController,cambiarEstadoEncuestaController,eliminarEncuestaController };