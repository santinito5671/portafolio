import { Component } from '@angular/core';

@Component({
  selector: 'app-masinfo',
  imports: [],
  templateUrl: './masinfo.html',
  styleUrl: './masinfo.css'
})
export class Masinfo {

}
