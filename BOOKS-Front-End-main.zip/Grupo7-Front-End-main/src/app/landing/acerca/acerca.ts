import { Component } from '@angular/core';

@Component({
  selector: 'app-acerca',
  imports: [],
  templateUrl: './acerca.html',
  styleUrl: './acerca.css'
})
export class Acerca {

}
