export interface IResponseApi {
    status: string,
    message: string,
}