INSTRUCCIONES PARA CORRER EL PROYECTO CHEF-MOVIL:

se recomienda instalar y correr el proyecto con Visual Studio Code
https://code.visualstudio.com/

Node.js

Descargar e instalar la última versión LTS de Node.js desde https://nodejs.org. Esto también instalará npm (Node Package Manager).
Verificar instalación ejecutando en la terminal (por ejemplo en visual studio code):

node -v
npm -v

Ionic CLI:

Instalar el CLI de Ionic globalmente usando npm:

npm install -g @ionic/cli

Verifica la instalación con:
ionic -v

Instalar dependencias del proyecto
Dentro del directorio del proyecto, ejecuta:

npm install

Ejecutar el proyecto en desarrollo
Para correr el proyecto en el navegador:

ionic serve

Documentacion en trello: https://trello.com/b/osRoKttP/tsds-pp2
