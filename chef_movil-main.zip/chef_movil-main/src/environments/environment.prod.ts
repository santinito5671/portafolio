export const environment = {
  production: true,

  firebaseConfig: {
    apiKey: "AIzaSyAp8VV5XpmGz5YLMaehh6SqrCM3ywe1XCQ",
    authDomain: "chefmovil-1abfc.firebaseapp.com",
    projectId: "chefmovil-1abfc",
    storageBucket: "chefmovil-1abfc.appspot.com",
    messagingSenderId: "493884769030",
    appId: "1:493884769030:web:b857048fcbfdb2e5131487",
    measurementId: "G-VGCGF71BGD"
  }
};
